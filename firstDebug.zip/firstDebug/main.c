#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x,y,r;

    printf("Enter your first number:\n");
    scanf("%d",&x);

    printf("Enter your second number:\n");
    scanf("%d",&y);

    r=x+y;

    printf("Sum is :%d\n",r);

    return 0;
 }
